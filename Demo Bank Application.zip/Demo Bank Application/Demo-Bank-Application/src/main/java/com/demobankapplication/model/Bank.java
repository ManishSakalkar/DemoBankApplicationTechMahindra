package com.demobankapplication.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class Bank {

    private Map<Long, Account> accounts;

    public Bank() {
        this.accounts = new HashMap<>();
    }

    public void addAccount(Account account) {
        accounts.put(account.getId(), account);
    }

    public void removeAccount(Long id) {
        accounts.remove(id);
    }

    public void displayAccountDetails() {
        for (Account account : accounts.values()) {
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Holder's Name: " + account.getAccountHolderName());
            System.out.println("Balance: " + account.getBalance());
            System.out.println("------------------------");
        }
    }

    public List<Account> searchByAccountNumber(String accountNumber) {
        List<Account> result = new ArrayList<>();
        for (Account account : accounts.values()) {
            if (account.getAccountNumber().equalsIgnoreCase(accountNumber)) {
                result.add(account);
            }
        }
        return result;
    }

    public List<Account> searchByHolderName(String holderName) {
        List<Account> result = new ArrayList<>();
        for (Account account : accounts.values()) {
            if (account.getAccountHolderName().equalsIgnoreCase(holderName)) {
                result.add(account);
            }
        }
        return result;
    }
}
