package com.demobankapplication.model;

import org.springframework.stereotype.Component;

import com.demobankapplication.exceptions.InsufficientBalanceException;

@Component
public class User {

    public Account createAccount(Bank bank, Account account) {
        bank.addAccount(account);
        return account;
    }

    public void depositMoney(Account account, Transaction transaction) {
        double currentBalance = account.getBalance();
        double depositAmount = transaction.getAmount();
        account.setBalance(currentBalance + depositAmount);
    }

    public void withdrawMoney(Account account, Transaction transaction) throws InsufficientBalanceException {
        double currentBalance = account.getBalance();
        double withdrawalAmount = transaction.getAmount();

        if (currentBalance < withdrawalAmount) {
            throw new InsufficientBalanceException("Insufficient funds");
        }

        account.setBalance(currentBalance - withdrawalAmount);
    }

    public void displayAccountDetails(Account account) {
        System.out.println("Account Number: " + account.getAccountNumber());
        System.out.println("Holder's Name: " + account.getAccountHolderName());
        System.out.println("Balance: " + account.getBalance());
        System.out.println("------------------------");
    }
}
