package com.demobankapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demobankapplication.exceptions.AccountNotFoundException;
import com.demobankapplication.exceptions.InsufficientBalanceException;
import com.demobankapplication.model.Account;
import com.demobankapplication.repo.AccountRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public Optional<Account> getAccountById(Long id) {
        return accountRepository.findById(id);
    }

//    public Optional<Account> getAccountByAccountNumber(String accountNumber) {
//        return Optional.ofNullable(accountRepository.findByAccountNumber(accountNumber));
//    }

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
    
    public List<Account> searchByAccountNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber);
    }

    public List<Account> searchByAccountHolderName(String accountHolderName) {
        return accountRepository.findByAccountHolderName(accountHolderName);
    }
    
    public Account updateAccount(Long id, Account updatedAccount) {
        Account existingAccount = getAccountById(id).orElseThrow(() -> new AccountNotFoundException("Account not found"));

        existingAccount.setAccountNumber(updatedAccount.getAccountNumber());
        existingAccount.setAccountHolderName(updatedAccount.getAccountHolderName());
        existingAccount.setBalance(updatedAccount.getBalance());

        return accountRepository.save(existingAccount);
    }

    public void deleteAccount(Long id) {
        if (!accountRepository.existsById(id)) {
            throw new AccountNotFoundException("Account not found");
        }

        accountRepository.deleteById(id);
    }

    public Account deposit(Long id, double amount) {
        Account account = getAccountById(id).orElseThrow(() -> new AccountNotFoundException("Account not found"));
        account.setBalance(account.getBalance() + amount);
        return accountRepository.save(account);
    }

    public Account withdraw(Long id, double amount) {
        Account account = getAccountById(id).orElseThrow(() -> new AccountNotFoundException("Account not found"));

        if (account.getBalance() < amount) {
            throw new InsufficientBalanceException("Insufficient funds");
        }

        account.setBalance(account.getBalance() - amount);
        return accountRepository.save(account);
    }
}
