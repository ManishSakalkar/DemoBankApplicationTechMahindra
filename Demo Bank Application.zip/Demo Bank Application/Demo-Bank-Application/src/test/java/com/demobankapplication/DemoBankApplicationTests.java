package com.demobankapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
